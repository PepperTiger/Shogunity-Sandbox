﻿
using System;
using System.IO;

namespace Sandbox {

	class MainClass {

		public static void Main (string [] args) {

			Console.SetWindowSize (100, 50);

			// Ask the user what game to initialize
			_init.setGameConfig ();

			// Start the total time spent timer
			var totalTime = System.Diagnostics.Stopwatch.StartNew ();

			_init.initGame ();

			_GameManager.initGameManager ();

			Console.WriteLine ("Lancement du GameLoop\n\n");
			_GameManager.gameLoop ();
			Console.WriteLine ("Fin du GameLoop");

			// Le StringBuilder workFlow est initialisé dans initGameManager()
			if (_GameManager.currentPlayerIndex == 0) {
				Console.WriteLine ("\n\nSENTE WON!\n");
				_GameManager.workFlow.Append ("SENTE WON!\n\n");
			} else {
				Console.WriteLine ("\n\nGOTE WON!\n");
				_GameManager.workFlow.Append ("GOTE WON!\n\n");
			}

			// Ouverture d'un fichier
			string file = "../../Logs/Game-" + new DirectoryInfo ("../../Logs").GetFiles ().Length + "---" + _GameManager.players [0].name + "-" + _GameManager.players [0].type + "-" + _GameConfig.player1Difficulty + "---" + _GameManager.players [1].name + "-" + _GameManager.players [1].type + "-" + _GameConfig.player2Difficulty + ".txt";

			// Stop the total time spent timer
			totalTime.Stop ();

			Console.WriteLine ("\nTemps total écoulé : " + totalTime.ElapsedMilliseconds + "ms\n\n");
			_GameManager.workFlow.Append ("\nTemps total écoulé : " + totalTime.ElapsedMilliseconds + "ms\n\n");

			// Ecriture du contenu du StringBuilder dans le fichier
			System.IO.File.WriteAllText (file, _GameManager.workFlow.ToString ());

			Environment.Exit (1);

		}

	}

}
