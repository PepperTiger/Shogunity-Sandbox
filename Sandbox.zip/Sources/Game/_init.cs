﻿using System;
using System.Collections;
using System.Collections.Generic;
using ShogiUtils;
using System.Text;

/// <summary>
/// Initialisation du jeu.
/// </summary>
public static class _init {

	/// <summary>
	/// ID employé pour init les tokens.
	/// </summary>
	public static int tokenId;

	/// <summary>
	/// Nombre de lignes dans le board.
	/// </summary>
	public static int nrow = 9;

	/// <summary>
	/// Nombre de colonnes dans le board.
	/// </summary>
	public static int ncol = 9;

	/// <summary>
	/// Boxes du board.
	/// </summary>
	public static List<Box> boxes = new List<Box> ();

	/// <summary>
	/// Tokens du board.
	/// </summary>
	public static List<Token> tokens = new List<Token> ();

	/// <summary>
	/// Joueurs 1=BLACK-SENTE, 2=WHITE-GOTE
	/// </summary>
	public static Player player1, player2;

	/// <summary>
	/// Les deux IA du jeu.
	/// </summary>
	public static AIHandler AI1, AI2;

	/// <summary>
	/// Les deux bancs de capture du board
	/// </summary>
	public static CaptureBench cb1, cb2;

	/// <summary>
	/// Initialisation des options de jeu.
	/// </summary>
	public static void setGameConfig () {

		int tmp = 0;

		do {
			Console.WriteLine ("\nType AI1 ? 1 : MiniMax, 2 : AlphaBeta, 3 : NegaScout, 4 : ProofNumberSearch\n");
			try {
				tmp = int.Parse (Console.ReadLine ());
			} catch (FormatException) {
				Console.WriteLine ("\nVeuillez entrer un nombre, vous avez tapé :" + tmp);
			}
		} while (tmp > 4 || tmp < 0);

		switch (tmp) {
			case 1:
				_GameConfig.player1Type = PlayerType.MINMAX;
				break;
			case 2:
				_GameConfig.player1Type = PlayerType.ALPHABETA;
				break;
			case 3:
				_GameConfig.player1Type = PlayerType.NEGASCOUT;
				break;
			case 4:
				_GameConfig.player1Type = PlayerType.PNS;
				break;
		}

		tmp = 0;

		do {
			Console.WriteLine ("\nDepth AI 1 ? From 1 to 5\n");
			try {
				tmp = int.Parse (Console.ReadLine ());
			} catch (FormatException) {
				Console.WriteLine ("\nVeuillez entrer un nombre");
			}
		} while (tmp < 1 || tmp > 5);
		_GameConfig.player1Difficulty = tmp;

		tmp = 0;

		do {
			Console.WriteLine ("\nType AI2 ? 1 : MiniMax, 2 : AlphaBeta, 3 : NegaScout, 4 : Proof Number Search\n");
			try {
				tmp = int.Parse (Console.ReadLine ());
			} catch (FormatException) {
				Console.WriteLine ("\nVeuillez entrer un nombre");
			}
		} while (tmp > 4 || tmp < 0);

		switch (tmp) {
			case 1:
				_GameConfig.player2Type = PlayerType.MINMAX;
				break;
			case 2:
				_GameConfig.player2Type = PlayerType.ALPHABETA;
				break;
			case 3:
				_GameConfig.player2Type = PlayerType.NEGASCOUT;
				break;
			case 4:
				_GameConfig.player2Type = PlayerType.PNS;
				break;
		}

		tmp = 0;

		do {
			Console.WriteLine ("\nDepth AI 2 ? From 1 to 5\n");
			try {
				tmp = int.Parse (Console.ReadLine ());
			} catch (FormatException) {
				Console.WriteLine ("\nVeuillez entrer un nombre");
			}
		} while (tmp < 1 || tmp > 5);
		_GameConfig.player2Difficulty = tmp;

	}

	/// <summary>
	/// Initialisation du jeu.
	/// </summary>
	public static void initGame () {

		tokenId = 0;

		_GameManager.workFlow = new StringBuilder ();

		// Création des cases
		generateBoxes ();

		// Création des joueurs
		generatePlayers ();

		// Création des pièces
		generatePlayer1Tokens (player1);
		generatePlayer2Tokens (player2);

		// Attribution de valeurs aux pièces
		generateTokenValues ();

		// Attribution des IA
		generateAI ();

		// Passage des références au game manager
		_GameManager.players = new Player[2] { player1, player2 };
		_GameManager.boxes = boxes;
		_GameManager.tokens = tokens;
		_GameManager.AI = new AIHandler[2] { AI1, AI2 };

		string tempo = "\nPlayer 1 : " + _GameManager.players [0].type + ", Player 2 : " + _GameManager.players [1].type + "\n";

		Console.WriteLine (tempo);
		_GameManager.workFlow.Append (tempo);

		tempo = "Depth Player 1 : " + _GameConfig.player1Difficulty + ", Depth Player 2 : " + _GameConfig.player2Difficulty + "\n\n\n";

		Console.WriteLine (tempo);
		_GameManager.workFlow.Append (tempo);

	}

	/// <summary>
	/// Création des cases.
	/// </summary>
	static void generateBoxes () {

		for (int i = 0; i < nrow; i++) {
			for (int j = 0; j < nrow; j++) {

				// Création de la case
				Box box = new Box ();

				// Positionnement de la case dans l'espace
				box.coord = new Coordinates (j, i);

				// Ajout de la case à la liste
				boxes.Add (box);

			}
		}

		// Capture boxes - Player 1
		cb1 = new CaptureBench ();

		// Capture boxes - Player 2
		cb2 = new CaptureBench ();

	}

	/// <summary>
	///	Creation des joueurs.
	/// </summary>
	static void generatePlayers () {

		player1 = new Player ("AI_1", _GameConfig.player1Type, ShogiUtils.GameColor.SENTE);
		player2 = new Player ("AI_2", _GameConfig.player2Type, ShogiUtils.GameColor.GOTE);

	}

	/// <summary>
	/// Creation des pièces du joueur blanc.
	/// </summary>
	/// <param name="player">Un joueur.</param>
	static void generatePlayer1Tokens (Player player) {

		Box box;

		// Pions
		for (int i = 18; i < 27; i++) {

			Pawn pawn = new Pawn ();

			box = boxes [i];
			pawn.owner = player;
			pawn.id = tokenId;
			tokenId++;
			tokens.Add (pawn);
			_GameManager.bindBoxAndToken (box, pawn);

		}

		// Tour
		Rook rook = new Rook ();

		box = boxes [16];
		rook.owner = player;
		rook.id = tokenId;
		tokenId++;
		tokens.Add (rook);
		_GameManager.bindBoxAndToken (box, rook);

		// Fou
		Bishop bishop = new Bishop ();

		box = boxes [10];
		bishop.owner = player;
		bishop.id = tokenId;
		tokenId++;
		tokens.Add (bishop);
		_GameManager.bindBoxAndToken (box, bishop);

		// Or
		Gold gold;

		gold = new Gold ();
		box = boxes [3];
		gold.owner = player;
		gold.id = tokenId;
		tokenId++;
		tokens.Add (gold);
		_GameManager.bindBoxAndToken (box, gold);

		gold = new Gold ();
		box = boxes [5];
		gold.owner = player;
		gold.id = tokenId;
		tokenId++;
		tokens.Add (gold);
		_GameManager.bindBoxAndToken (box, gold);

		// Argent
		Silver silver;

		silver = new Silver ();
		box = boxes [2];
		silver.owner = player;
		silver.id = tokenId;
		tokenId++;
		tokens.Add (silver);
		_GameManager.bindBoxAndToken (box, silver);

		silver = new Silver ();
		box = boxes [6];
		silver.owner = player;
		silver.id = tokenId;
		tokenId++;
		tokens.Add (silver);
		_GameManager.bindBoxAndToken (box, silver);

		// Cavalier
		Knight knight;

		knight = new Knight ();
		box = boxes [1];
		knight.owner = player;
		knight.id = tokenId;
		tokenId++;
		tokens.Add (knight);
		_GameManager.bindBoxAndToken (box, knight);

		knight = new Knight ();
		box = boxes [7];
		knight.owner = player;
		knight.id = tokenId;
		tokenId++;
		tokens.Add (knight);
		_GameManager.bindBoxAndToken (box, knight);

		// Lancier
		Lance lance;

		lance = new Lance ();
		box = boxes [0];
		lance.owner = player;
		lance.id = tokenId;
		tokenId++;
		tokens.Add (lance);
		_GameManager.bindBoxAndToken (box, lance);

		lance = new Lance ();
		box = boxes [8];
		lance.owner = player;
		lance.id = tokenId;
		tokenId++;
		tokens.Add (lance);
		_GameManager.bindBoxAndToken (box, lance);


		// Roi
		King king = new King ();

		box = boxes [4];
		king.owner = player;
		king.id = tokenId;
		tokenId++;
		tokens.Add (king);
		_GameManager.bindBoxAndToken (box, king);

	}

	/// <summary>
	/// Creation des pièces du joueur noir.
	/// </summary>
	/// <param name="player">Un joueur.</param>
	static void generatePlayer2Tokens (Player player) {

		Box box;

		// Pions
		for (int i = 54; i < 63; i++) {

			Pawn pawn = new Pawn ();

			box = boxes [i];
			pawn.owner = player2;
			pawn.id = tokenId;
			tokenId++;
			tokens.Add (pawn);
			_GameManager.bindBoxAndToken (box, pawn);

		}

		// Tour
		Rook rook = new Rook ();

		box = boxes [64];
		rook.owner = player;
		rook.id = tokenId;
		tokenId++;
		tokens.Add (rook);
		_GameManager.bindBoxAndToken (box, rook);

		// Fou
		Bishop bishop = new Bishop ();

		box = boxes [70];
		bishop.owner = player;
		bishop.id = tokenId;
		tokenId++;
		tokens.Add (bishop);
		_GameManager.bindBoxAndToken (box, bishop);

		// Or
		Gold gold;

		gold = new Gold ();
		box = boxes [77];
		gold.owner = player;
		gold.id = tokenId;
		tokenId++;
		tokens.Add (gold);
		_GameManager.bindBoxAndToken (box, gold);

		gold = new Gold ();
		box = boxes [75];
		gold.owner = player;
		gold.id = tokenId;
		tokenId++;
		tokens.Add (gold);
		_GameManager.bindBoxAndToken (box, gold);

		// Argent
		Silver silver;

		silver = new Silver ();
		box = boxes [78];
		silver.owner = player;
		silver.id = tokenId;
		tokenId++;
		tokens.Add (silver);
		_GameManager.bindBoxAndToken (box, silver);

		silver = new Silver ();
		box = boxes [74];
		silver.owner = player;
		silver.id = tokenId;
		tokenId++;
		tokens.Add (silver);
		_GameManager.bindBoxAndToken (box, silver);

		// Cavalier
		Knight knight;

		knight = new Knight ();
		box = boxes [79];
		knight.owner = player;
		knight.id = tokenId;
		tokenId++;
		tokens.Add (knight);
		_GameManager.bindBoxAndToken (box, knight);

		knight = new Knight ();
		box = boxes [73];
		knight.owner = player;
		knight.id = tokenId;
		tokenId++;
		tokens.Add (knight);
		_GameManager.bindBoxAndToken (box, knight);

		// Lancier
		Lance lance;

		lance = new Lance ();
		box = boxes [80];
		lance.owner = player;
		lance.id = tokenId;
		tokenId++;
		tokens.Add (lance);
		_GameManager.bindBoxAndToken (box, lance);

		lance = new Lance ();
		box = boxes [72];
		lance.owner = player;
		lance.id = tokenId;
		tokenId++;
		tokens.Add (lance);
		_GameManager.bindBoxAndToken (box, lance);

		// Roi
		Jewel jewel = new Jewel ();

		box = boxes [76];
		jewel.owner = player;
		jewel.id = tokenId;
		tokenId++;
		tokens.Add (jewel);
		_GameManager.bindBoxAndToken (box, jewel);
	}

	/// <summary>
	/// Affectation des valeurs aux pièces créées.
	/// </summary>
	public static void generateTokenValues () {

		foreach (Token t in tokens) {
			switch (t.getTokenType ()) {
				case TokenType.PAWN:
					t.value = 100;
					break;
				case TokenType.LANCE:
					t.value = 300;
					break;
				case TokenType.KNIGHT:
					t.value = 400;
					break;
				case TokenType.SILVER:
					t.value = 500;
					break;
				case TokenType.BISHOP:
					t.value = 800;
					break;
				case TokenType.ROOK:
					t.value = 1000;
					break;
				case TokenType.GOLD:
					t.value = 600;
					break;
				case TokenType.KING:
					t.value = 10000;
					break;
			}
		}

	}

	/// <summary>
	/// Generation des IA.
	/// </summary>
	public static void generateAI () {

		AI1 = null;
		AI2 = null;

		switch (_GameConfig.player1Type) {

			case PlayerType.ALPHABETA:
				AI1 = new AlphaBeta (player1, player2);
				break;
			case PlayerType.MINMAX:
				AI1 = new MiniMax (player1, player2);
				break;
			case PlayerType.NEGASCOUT:
				AI1 = new NegaScout (player1, player2);
				break;
			case PlayerType.PNS:
				AI1 = new ProofNumberSearch (player1, player2);
				break;

		}

		switch (_GameConfig.player2Type) {

			case PlayerType.ALPHABETA:
				AI2 = new AlphaBeta (player2, player1);
				break;
			case PlayerType.MINMAX:
				AI2 = new MiniMax (player2, player1);
				break;
			case PlayerType.NEGASCOUT:
				AI2 = new NegaScout (player2, player1);
				break;
			case PlayerType.PNS:
				AI2 = new ProofNumberSearch (player2, player1);
				break;

		}

	}

}
