﻿using System.Collections;
using System.Collections.Generic;
using ShogiUtils;
using System.Linq;
using System;

/// <summary>
/// Classe fou.
/// </summary>
[Serializable]
public class Bishop : Token {
	
	/// <summary>
	/// Mouvements autorisés par la pièce.
	/// </summary>
	/// <returns>Une liste de coordonnées autorisées lors des déplacements.</returns>
	public override List<Coordinates> legalMoves (Board board) {
		
		List<Coordinates> coordinates = new List<Coordinates> ();
		Coordinates c;
		bool ok;

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.TOP_LEFT, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.BOTTOM_LEFT, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.BOTTOM_RIGHT, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.TOP_RIGHT, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		return coordinates;

	}

	/// <summary>
	/// Retourne le type de la pièce.
	/// </summary>
	/// <returns>Retour du type de la pièce.</returns>
	public override TokenType getTokenType () {
		
		return TokenType.BISHOP;

	}

	/// <summary>
	/// Valeur de la position de la pièce.
	/// </summary>
	/// <returns>La valeur.</returns>
	/// <param name="king">Coordonnées du roi ennemi ennemi.</param>
	/// <param name="board">Tableau de jeu.</param>
	public override int positionValue (Coordinates king, Board board) {
		
		int diffX = box.coord.x - king.x;
		int diffY = box.coord.y - king.y;
		int sumX = box.coord.x + king.x;
		int sumY = box.coord.y + king.y;

		if (king.x == box.coord.x || king.y == box.coord.y || (Math.Abs (diffX) != Math.Abs (diffY) && sumX != sumY)) {
			
			return 0;

		}

		Boolean obstacle = false;
		int yDir = king.y > box.coord.y ? 1 : -1;
		int xDir = king.x > box.coord.x ? 1 : -1;

		for (int i = 1; i < Math.Abs (diffY); i++) {
			if (board.boxes [box.coord.getIndex () + (9 * i * yDir) + i * xDir].token != null) {
				obstacle = true;
				break;
			}
		}

		return obstacle ? 10 : 400;

	}

}
