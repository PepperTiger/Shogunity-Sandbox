﻿using System.Collections;
using System.Collections.Generic;
using ShogiUtils;
using System.Linq;
using System;

/// <summary>
/// Classe tour.
/// </summary>
[Serializable]
public class Rook : Token {

	/// <summary>
	/// Retourne le type de la pièce.
	/// </summary>
	/// <returns>Retour du type de la pièce.</returns>
	public override TokenType getTokenType () {
		
		return TokenType.ROOK;

	}

	/// <summary>
	/// Mouvements autorisés par la pièce.
	/// </summary>
	/// <returns>Une liste de coordonnées autorisées lors des déplacements.</returns>
	/// <param name="board">Le plateau de jeu.</param>
	public override List<Coordinates> legalMoves (Board board) {
		
		List<Coordinates> coordinates = new List<Coordinates> ();
		Coordinates c;
		bool ok;

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.TOP, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.LEFT, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.BOTTOM, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		ok = true;
		c = box.coord;
		while (ok) {
			c = c.getNeighbor (Neighbor.RIGHT, owner.color);
			if (c.isInsideBorders ()) {
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					coordinates.Add (c);
				} else if (b.token.owner.color != owner.color) {
					coordinates.Add (c);
					ok = false;
				} else {
					ok = false;
				}
			} else {
				ok = false;
			}
		}

		return coordinates;

	}

	/// <summary>
	/// Mouvements complémentaires (de promotion) autorisés par la pièce.
	/// </summary>
	/// <returns>Une liste de coordonnées complémentaires (de promotion) autorisées lors des déplacements.</returns>
	/// <param name="board">Le plateau de jeu.</param>
	public override List<Coordinates> legalMovesPlus (Board board) {
		
		List<Coordinates> coordinates = base.legalMovesPlus (board);
		Coordinates c;

		// BOTTOM LEFT
		c = box.coord.getNeighbor (Neighbor.BOTTOM_LEFT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		// BOTTOM RIGHT
		c = box.coord.getNeighbor (Neighbor.BOTTOM_RIGHT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		return coordinates;

	}

	/// <summary>
	/// Valeur de la position de la pièce.
	/// </summary>
	/// <returns>La valeur.</returns>
	/// <param name="king">Coordonnées du roi ennemi.</param>
	/// <param name="board">Tableau de jeu.</param>
	public override int positionValue (Coordinates king, Board board) {
		
		if (box.coord.x != king.x && box.coord.y != king.y) {
			
			return 0; // Ni sur la meme ligne ni la meme colonne

		} else {
			
			Boolean obstacle = false;
			if (king.x == box.coord.x) { // Meme colonne
				int yDir = king.y > box.coord.y ? 1 : -1;
				for (int i = 1; i < Math.Abs (box.coord.y - king.y); i++) {
					if (board.boxes [box.coord.getIndex () + 9 * i * yDir].token != null) {
						obstacle = true;
						break;
					}
				}
			} else { // Meme ligne
				int xDir = king.x > box.coord.x ? 1 : -1;
				for (int i = 1; i < box.coord.y - king.y; i += xDir) {
					if (board.boxes [box.coord.getIndex () + 9 * i * xDir].token != null) {
						obstacle = true;
						break;
					}
				}
			}
			if (Math.Abs (box.coord.y - king.y) >= 2 && Math.Abs (box.coord.y - king.y) < 6) {
				return obstacle ? 0 : 200;
			}

			return obstacle ? 0 : 100;

		}
	}

}
