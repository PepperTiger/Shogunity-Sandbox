using System.Collections;
using System.Collections.Generic;
using ShogiUtils;
using System.Linq;
using System;

/// <summary>
/// Classe g�n�ral d'argent.
/// </summary>
[Serializable]
public class Silver : Token {

	/// <summary>
	/// Mouvements autoris�s par la pi�ce.
	/// </summary>
	/// <returns>Une liste de coordonn�es autoris�es lors des d�placements.</returns>
	/// <param name="board">Le plateau de jeu.</param>
	public override List<Coordinates> legalMoves (Board board) {
		
		List<Coordinates> coordinates = new List<Coordinates> ();
		Coordinates c;

		c = box.coord.getNeighbor (Neighbor.TOP, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.TOP_LEFT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.TOP_RIGHT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.BOTTOM_LEFT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.BOTTOM_RIGHT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		return coordinates;

	}

	/// <summary>
	/// Mouvements compl�mentaires (de promotion) autoris�s par la pi�ce.
	/// </summary>
	/// <returns>Une liste de coordonn�es compl�mentaires (de promotion) autoris�es lors des d�placements.</returns>
	public override List<Coordinates> legalMovesPlus (Board board) {
		
		List<Coordinates> coordinates = new List<Coordinates> ();
		Coordinates c;

		c = box.coord.getNeighbor (Neighbor.TOP, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.TOP_LEFT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.TOP_RIGHT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.LEFT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.RIGHT, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		c = box.coord.getNeighbor (Neighbor.BOTTOM, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		return coordinates;

	}

	/// <summary>
	/// Retourne le type de la pi�ce.
	/// </summary>
	/// <returns>Retour du type de la pi�ce.</returns>
	public override TokenType getTokenType () {
		
		return TokenType.SILVER;

	}

	/// <summary>
	/// Valeur de la position de la pi��ce.
	/// </summary>
	/// <returns>La valeur.</returns>
	/// <param name="king">Coordonn��es du roi ennemi.</param>
	/// <param name="board">Tableau de jeu.</param>
	public override int positionValue (Coordinates king, Board board) {
		
		if (isPromoted) {
			return positionValueGoldPattern (king);
		}

		return Math.Max (0, 200 - 33 * Math.Abs (king.y - box.coord.y));

	}

}
