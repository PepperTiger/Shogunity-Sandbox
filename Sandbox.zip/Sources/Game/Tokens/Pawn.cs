using System.Collections;
using System.Collections.Generic;
using ShogiUtils;
using System.Linq;
using System;

/// <summary>
/// Classe pion.
/// </summary>
[Serializable]
public class Pawn : Token {

	/// <summary>
	/// Mouvements autorisés par la pièce.
	/// </summary>
	/// <returns>Une liste de coordonnées autorisées lors des déplacements.</returns>
	/// <param name="board">Le plateau de jeu.</param>
	public override List<Coordinates> legalMoves (Board board) {
		
		List<Coordinates> coordinates = new List<Coordinates> ();
		Coordinates c;

		c = box.coord.getNeighbor (Neighbor.TOP, owner.color);
		if (c.isInsideBorders ()) {
			Box b = board.boxes [c.getIndex ()];
			if (b.token == null || b.token.owner.color != owner.color) {
				coordinates.Add (c);
			}
		}

		return coordinates;

	}

	/// <summary>
	/// Listes les rédéploiements autorisés par la pièce.
	/// </summary>
	/// <returns>Une liste de coordonnées autorisées lors des rédeploiements.</returns>
	/// <param name="board">Le plateau de jeu.</param>
	public override List<Coordinates> legalDrops (Board board) {
		
		List<Coordinates> coordinates = new List<Coordinates> ();
		Coordinates c;

		int firstRow = (owner.color == GameColor.SENTE) ? 0 : 1;
		int lastRow = (owner.color == GameColor.SENTE) ? 8 : 9;
		for (int i = 0; i < 9; i++) {
			bool columnOK = true;
			List<Coordinates> columnCoord = new List<Coordinates> ();
			for (int j = firstRow; j < lastRow && columnOK; j++) {
				c = new Coordinates (i, j);
				Box b = board.boxes [c.getIndex ()];
				if (b.token == null) {
					columnCoord.Add (c);
				} else if (b.token.type == TokenType.PAWN && b.token.isPromoted == false && this.owner == b.token.owner) {
					columnOK = false;
				}
			}
			if (columnOK) coordinates.AddRange (columnCoord);
		}

		return coordinates;

	}

	/// <summary>
	/// Retourne le type de la pièce.
	/// </summary>
	/// <returns>Retour du type de la pièce.</returns>
	public override TokenType getTokenType () {
		
		return TokenType.PAWN;

	}

	/// <summary>
	/// Valeur de la position de la pièce.
	/// </summary>
	/// <returns>La valeur.</returns>
	/// <param name="king">Coordonnées du roi ennemi.</param>
	/// <param name="board">Tableau de jeu.</param>
	public override int positionValue (Coordinates king, Board board) {
		
		if (isPromoted) {
			return positionValueGoldPattern (king);
		}

		if (owner.color == GameColor.GOTE && box.coord.y > king.y || owner.color != GameColor.GOTE && box.coord.y < king.y) {	
			return 1;
		}

		return Math.Max (100 - 13 * Math.Abs (box.coord.y - king.y), 1);
        
	}

}
