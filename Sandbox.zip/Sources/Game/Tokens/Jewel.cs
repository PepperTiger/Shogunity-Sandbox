﻿using System.Collections;
using System.Linq;
using System;

/// <summary>
/// Classe roi de jade.
/// </summary>
[Serializable]
public class Jewel : King {
	
}
